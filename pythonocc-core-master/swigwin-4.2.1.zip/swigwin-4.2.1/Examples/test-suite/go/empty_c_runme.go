package main

import _ "swigtests/empty_c"

func main() {
}

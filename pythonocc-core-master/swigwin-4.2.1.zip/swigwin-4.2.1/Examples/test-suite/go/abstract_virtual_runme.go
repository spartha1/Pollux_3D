package main

import "swigtests/abstract_virtual"

func main() {
	abstract_virtual.NewD()
	abstract_virtual.NewE()
}

var preproc_gcc_output = require("preproc_gcc_output");

preproc_gcc_output.header1_function_a(99);
preproc_gcc_output.header1_function_b(99);
preproc_gcc_output.header2_function(99);

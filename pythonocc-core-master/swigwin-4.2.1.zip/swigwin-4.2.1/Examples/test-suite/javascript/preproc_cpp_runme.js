var preproc_cpp = require("preproc_cpp");

t1 = new preproc_cpp.tcxMessageTest();
t2 = new preproc_cpp.tcxMessageBug();

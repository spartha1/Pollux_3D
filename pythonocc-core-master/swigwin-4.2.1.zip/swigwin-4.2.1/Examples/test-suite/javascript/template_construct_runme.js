var template_construct = require("template_construct")

f = new template_construct.Foo_int(2);

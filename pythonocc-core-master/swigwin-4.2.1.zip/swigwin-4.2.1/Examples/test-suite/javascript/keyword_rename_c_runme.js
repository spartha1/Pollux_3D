var keyword_rename_c = require("keyword_rename_c");
keyword_rename_c._instanceof(1);
keyword_rename_c._finally(1);

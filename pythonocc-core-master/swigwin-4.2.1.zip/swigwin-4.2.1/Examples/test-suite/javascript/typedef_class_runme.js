var typedef_class = require("typedef_class");

a = new typedef_class.RealA();
a.a = 3;

b = new typedef_class.B();
b.testA(a);

var cpp11_initializer_list = require("cpp11_initializer_list");

a = new cpp11_initializer_list.A();
a = new cpp11_initializer_list.A(11.1);

var namespace_virtual_method = require("namespace_virtual_method");

x = new namespace_virtual_method.Spam();

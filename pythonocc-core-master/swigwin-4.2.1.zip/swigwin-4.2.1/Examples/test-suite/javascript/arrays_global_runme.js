var arrays_global = require("arrays_global");

arrays_global.array_i = arrays_global.array_const_i;

arrays_global.BeginString_FIX44a;
arrays_global.BeginString_FIX44b;
arrays_global.BeginString_FIX44c;
arrays_global.BeginString_FIX44d;
arrays_global.BeginString_FIX44d;
arrays_global.BeginString_FIX44b = "12"+'\0'+"45";
arrays_global.BeginString_FIX44b;
arrays_global.BeginString_FIX44d;
arrays_global.BeginString_FIX44e;
arrays_global.BeginString_FIX44f;

arrays_global.test_a("hello","hi","chello","chi");

arrays_global.test_b("1234567","hi");

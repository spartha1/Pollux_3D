var template_ref_type = require("template_ref_type");

xr = new template_ref_type.XC();
y = new template_ref_type.Y();
y.find(xr);
